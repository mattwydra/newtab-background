# Phase 5d
Version 5a [zip](https://mattwydra.github.io/newtab-background/v5/v5d/ext1.zip)

## **Objective:**
- Add more sites to the presets
- Allow for adding/removing from presets
- Will support more options:
   - hide bookmarks (done)
   - hide individual elements (search bar, sites, etc.)
   - add images (or videos/gifs, etc.)
   - add quotes