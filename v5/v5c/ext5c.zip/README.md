# Phase 5c

## **Objective:**
- **v5c**: Implement toggle for automatic hopecore refresh after 10 seconds
   - potential addon: custom time limits for hopecore refresh. 