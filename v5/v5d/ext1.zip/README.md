# Phase 5d

## **Objective:**
- Add more sites to the presets
- Allow for adding/removing from presets
- Will support more options:
   - hide bookmarks (done)
   - hide individual elements (search bar, sites, etc.)
   - add images (or videos/gifs, etc.)
   - add quotes