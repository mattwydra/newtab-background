# Phase 5a

## **Objective:**
- **v5a**: Display a hopecore image and quote on new tab load.