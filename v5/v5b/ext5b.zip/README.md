# Phase 5b

## **Objective:**
- **v5b**: Implement 'generate hopecore' button so the user can continuously generate a new hopecore background + quote combination.